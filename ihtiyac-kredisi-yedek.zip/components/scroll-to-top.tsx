"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"

export function ScrollToTop({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  return <>{children}</>
}
